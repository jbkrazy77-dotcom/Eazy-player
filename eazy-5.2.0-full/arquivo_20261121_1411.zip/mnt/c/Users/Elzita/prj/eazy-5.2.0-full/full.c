#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/inotify.h>
#include <limits.h>
#include <time.h>
#define FULL_VERSION "full (eazy 5.2.0 rev.39)"

// =========================================================================
// ÁREA DE CONFIGURAÇÃO (Suporta até 1 milhão de watches em O(1))
// =========================================================================

#define MAX_WATCH_ID 1048576
#define PASTA_FILA "/dev/shm/fila_eventos"

const char *PASTAS_IGNORADAS[] = {
    "cache",
    "sql-list-views",
    "anon_",
    NULL
};

const char *SUFIXOS_IGNORADOS[] = {
    "-journal",
    "-wal",
    "-shm",
    NULL
};

// =========================================================================
// VARIÁVEIS DE CONTROLE
// =========================================================================

int opt_hidden = 0; // /h -> ler arquivos e pastas ocultos (.)
int opt_only   = 0; // /o -> monitorar apenas a pasta raiz
int opt_sub    = 0; // /s -> recursivo (padrão)
int opt_start  = 0; // /start -> gera tickets .evt na RAM (/dev/shm/fila_eventos)

unsigned long seq_evento = 0;
int watch_count = 0;

// Tabela de acesso direto O(1): o índice é o próprio Watch Descriptor (wd) do kernel
char *watches[MAX_WATCH_ID];

#define EVENT_BUF_LEN (4096 * (sizeof(struct inotify_event) + NAME_MAX + 1))

int deve_ignorar(const char *nome, int is_dir) {
    if (!opt_hidden && *nome == '.') {
        return 1;
    }

    if (opt_start) {
        if (is_dir) {
            for (int i = 0; PASTAS_IGNORADAS[i] != NULL; i++) {
                if (strstr(nome, PASTAS_IGNORADAS[i]) != NULL) return 1;
            }
        } else {
            size_t len_nome = strlen(nome);
            for (int i = 0; SUFIXOS_IGNORADOS[i] != NULL; i++) {
                size_t len_suf = strlen(SUFIXOS_IGNORADOS[i]);
                if (len_nome >= len_suf && strcmp(nome + len_nome - len_suf, SUFIXOS_IGNORADOS[i]) == 0) {
                    return 1;
                }
            }
        }
    }
    return 0;
}

void formatar_tamanho(long long bytes, char *saida, size_t max_len) {
    const char *unidades[] = {"B", "KB", "MB", "GB", "TB"};
    int i = 0;
    double valor = (double)bytes;

    while (valor >= 1024.0 && i < 4) {
        valor /= 1024.0;
        i++;
    }

    if (i == 0) {
        snprintf(saida, max_len, "%lld B", bytes);
    } else {
        snprintf(saida, max_len, "%.2f %s", valor, unidades[i]);
    }
}

void gravar_ticket_fila(const char *linha_evento) {
    char arq_tmp[PATH_MAX];
    char arq_final[PATH_MAX];
    time_t agora = time(NULL);
    seq_evento++;

    snprintf(arq_tmp, sizeof(arq_tmp), "%s/%ld_%06lu.tmp", PASTA_FILA, (long)agora, seq_evento);
    snprintf(arq_final, sizeof(arq_final), "%s/%ld_%06lu.evt", PASTA_FILA, (long)agora, seq_evento);

    FILE *f = fopen(arq_tmp, "w");
    if (!f) return;

    fprintf(f, "%s\n", linha_evento);
    fclose(f);

    rename(arq_tmp, arq_final);
}

void emitir_evento(const char *tipo, const char *caminho, int buscar_stat) {
    char tamanho_legivel[32] = "0 B";
    char data_hora[32] = "00/00/0000 00:00:00";
    char linha_completa[PATH_MAX + 128];
    struct stat st;
    struct tm *tm_info;

    if (buscar_stat && stat(caminho, &st) == 0) {
        formatar_tamanho((long long)st.st_size, tamanho_legivel, sizeof(tamanho_legivel));
        tm_info = localtime(&st.st_mtime);
        if (tm_info) {
            strftime(data_hora, sizeof(data_hora), "%d/%m/%Y %H:%M:%S", tm_info);
        }
    } else {
        time_t agora = time(NULL);
        tm_info = localtime(&agora);
        if (tm_info) {
            strftime(data_hora, sizeof(data_hora), "%d/%m/%Y %H:%M:%S", tm_info);
        }
    }

    snprintf(linha_completa, sizeof(linha_completa), "%-8s | %-10s | %s | %s", tipo, tamanho_legivel, data_hora, caminho);

    if (opt_start) {
        gravar_ticket_fila(linha_completa);
    } else {
        printf("%s\n", linha_completa);
        fflush(stdout);
    }
}

void add_watch(int fd, const char *path) {
    uint32_t mask = IN_CREATE | IN_CLOSE_WRITE | IN_DELETE | IN_MOVED_TO | IN_MOVED_FROM;
    int wd = inotify_add_watch(fd, path, mask);
    if (wd < 0 || wd >= MAX_WATCH_ID) return;

    if (watches[wd] != NULL) {
        free(watches[wd]);
    } else {
        watch_count++;
    }

    watches[wd] = strdup(path);

    if (!opt_start) {
        printf("[DEBUG +WATCH] %s\n", path);
    }
}

void remove_watch(int wd) {
    if (wd >= 0 && wd < MAX_WATCH_ID && watches[wd] != NULL) {
        if (!opt_start) {
            printf("[DEBUG -WATCH] %s\n", watches[wd]);
        }
        free(watches[wd]);
        watches[wd] = NULL;
        watch_count--;
    }
}

const char* get_watch_path(int wd) {
    if (wd >= 0 && wd < MAX_WATCH_ID && watches[wd] != NULL) {
        return watches[wd];
    }
    return "";
}

void mapear_diretorios(int fd, const char *base_path) {
    add_watch(fd, base_path);

    if (opt_only) return;

    DIR *dir = opendir(base_path);
    if (!dir) return;

    struct dirent *entry;
    char full_path[PATH_MAX];

    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
            continue;

        if (deve_ignorar(entry->d_name, 1))
            continue;

        snprintf(full_path, sizeof(full_path), "%s/%s", base_path, entry->d_name);

        struct stat statbuf;
        if (stat(full_path, &statbuf) == 0 && S_ISDIR(statbuf.st_mode)) {
            mapear_diretorios(fd, full_path);
        }
    }
    closedir(dir);
}

void mostrar_ajuda(const char *prog) {
    printf("Uso: %s [diretorio] [/h] [/o | /s] [/start]\n\n", prog);
    printf("Parametros:\n");
    printf("  /h      Inclui arquivos e pastas ocultos (iniciados com ponto)\n");
    printf("  /o      Monitora APENAS o diretorio informado (nao recursivo)\n");
    printf("  /s      Monitora recursivamente todas as subpastas (padrao)\n");
    printf("  /start  Gera tickets .evt em %s para consumo do script\n", PASTA_FILA);
}

int main(int argc, char *argv[]) {
    const char *root_dir = NULL;

    for (int i = 1; i < argc; i++) {
        if (strcasecmp(argv[i], "/v") == 0 || strcmp(argv[i], "--version") == 0) { printf("%s\n", FULL_VERSION); return 0; }
        if (strcasecmp(argv[i], "/h") == 0) {
            opt_hidden = 1;
        } else if (strcasecmp(argv[i], "/o") == 0) {
            opt_only = 1;
            opt_sub = 0;
        } else if (strcasecmp(argv[i], "/s") == 0) {
            opt_sub = 1;
            opt_only = 0;
        } else if (strcasecmp(argv[i], "/start") == 0) {
            opt_start = 1;
        } else if (strcmp(argv[i], "/?") == 0 || strcmp(argv[i], "--help") == 0) {
            mostrar_ajuda(*argv);
            return 0;
        } else {
            root_dir = argv[i];
        }
    }

    if (!root_dir) {
        root_dir = ".";
    }

    mkdir(PASTA_FILA, 0755);

    char clean_root[PATH_MAX];
    strncpy(clean_root, root_dir, PATH_MAX - 1);
    clean_root[PATH_MAX - 1] = '\0';
    size_t len = strlen(clean_root);
    if (len > 1 && clean_root[len - 1] == '/') {
        clean_root[len - 1] = '\0';
    }

    int fd = inotify_init();
    if (fd < 0) {
        perror("inotify_init");
        return 1;
    }

    if (!opt_start) {
        printf("=== full (eazy 5.2.0 rev.39) | DEBUG ===\n");
        printf("Alvo: %s | Fila (/start): %s\n", clean_root, PASTA_FILA);
    }

    mapear_diretorios(fd, clean_root);

    if (!opt_start) {
        printf("Total monitorado: %d pasta(s). Aguardando eventos...\n\n", watch_count);
    }

    char buffer[EVENT_BUF_LEN];

    while (1) {
        int length = read(fd, buffer, EVENT_BUF_LEN);
        if (length < 0) break;

        int i = 0;
        while (i < length) {
            struct inotify_event *event = (struct inotify_event *) &buffer[i];

            if (event->mask & IN_IGNORED) {
                remove_watch(event->wd);
            } 
            else if (event->len) {
                const char *parent_path = get_watch_path(event->wd);
                char full_event_path[PATH_MAX];
                snprintf(full_event_path, sizeof(full_event_path), "%s/%s", parent_path, event->name);

                int is_dir = (event->mask & IN_ISDIR) ? 1 : 0;

                if (deve_ignorar(event->name, is_dir)) {
                    i += sizeof(struct inotify_event) + event->len;
                    continue;
                }

                if (is_dir) {
                    if (!opt_only && (event->mask & (IN_CREATE | IN_MOVED_TO))) {
                        mapear_diretorios(fd, full_event_path);
                    }
                    if (!opt_start) {
                        if (event->mask & IN_CREATE) emitir_evento("PASTA +", full_event_path, 0);
                        if (event->mask & IN_DELETE) emitir_evento("PASTA -", full_event_path, 0);
                    }
                } 
                else {
                    if (event->mask & IN_CREATE) {
                        emitir_evento("CRIADO", full_event_path, 1);
                    }
                    else if (event->mask & (IN_CLOSE_WRITE | IN_MOVED_TO)) {
                        emitir_evento("PRONTO", full_event_path, 1);
                    } 
                    else if (event->mask & (IN_DELETE | IN_MOVED_FROM)) {
                        emitir_evento("REMOVIDO", full_event_path, 0);
                    }
                }
            }
            i += sizeof(struct inotify_event) + event->len;
        }
    }

    close(fd);
    return 0;
}
